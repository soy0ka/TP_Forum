const Discord = require('discord.js');

module.exports.run = async (client, message, args) => {
   message.channel.send('야숭이')
}


module.exports.help = {
    name : "도움말",
    aliases: ['도움', 'help']
}